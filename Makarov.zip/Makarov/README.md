APEA Corpus, Version 20170424
=============================

Author: Peter Makarov (makarov@cl.uzh.ch)
Last modified: 12.11.2018

If you use these data in your work, please reference

  Peter Makarov, Jasmine Lorenzini, and Hanspeter Kriesi. 2016.
  Constructing an Annotated Corpus for Protest Event Mining.
  In Proceedings of the Workshop on Natural Language Processing
  and Computational Social Science at EMNLP 2016.

The corpus contains three sets of annotations for overlapping subsets of the LDC
English Gigaword Third Edition Corpus (Graff et al., 2007), one set of
annotations for each annotator.

The annotations are stored in a format resembling that of the ACE 2005 corpus
(Doddington et al., 2004). An annotation file consists of event mentions and
events. An `event_mention` marks an event extent, which typically spans an
English sentence. It contains a list of `anchor` entities and
`event_mention_argument` entities. An anchor or an event mention argument embed
a `charseq` entity that contains character offset information about the
annotated string. `event_mention_argument` entities have a role attribute
(`Actor`, `Date`, `Location`, `Size`, and `Issue`). An `event_mention` refers to
an `event` by way of an id. Events, listed after the event mentions, have the
following child elements: `action_form`, `location`, `date_range`, `size`,
`actors`, `issues`, `link`, and `comment`. `action_form`, `location`,
`date_range`, and `size` have unique values. `date_range` shows the start and
the end date and possibly contain an `approximate` tag, indicating that the date
is not exact. `actors` and `issues` contain zero or more actor and issue
categories. `comment` is some additional free-text information that the
annotator decided to share about this event annotation. `link` points to an
event mention that refers to this event.

More information about the set of labels or the annotation process can found in
the publication and the annotation guidelines at the following url:

https://pub.cl.uzh.ch/projects/nccr/polcon/guidelines

Contact: Peter Makarov (makarov@cl.uzh.ch)

Licensed under CC-BY-4.0: https://creativecommons.org/licenses/by/4.0/
